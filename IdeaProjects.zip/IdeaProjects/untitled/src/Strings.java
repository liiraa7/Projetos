import javax.swing.plaf.synth.SynthOptionPaneUI;

public class Strings {
    public static void main(String[]args){


        String original = "abcde FGHIJ klmno PQRSTUV   ";

        // Deixar todas letras miniscula
        String s01 = original.toLowerCase();

        // Deixar tudo maiusculo
        String s02 = original.toUpperCase();

        // Remover Espaços em brancos/Invisiveis
        String s03 = original.trim();

        //Gerar uma String a parti de algum caractere
        String s04 = original.substring(2,10);

        //Trocar String por outra String
        String s05 = original.replace("abc", "xwxyz");

        System.out.println(original);
        System.out.println(s01);
        System.out.println(s02);
        System.out.println(s03);
        System.out.println(s04);
        System.out.println(s05);

    }
}
