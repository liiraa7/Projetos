import java.util.Scanner;

public class For {
    public static void main(String[]args){

        System.out.print("Digite quantas numeros vc quer que repita");

        Scanner sc = new Scanner(System.in);

        int quant = sc.nextInt();

        for (int i = 0; i != quant; i++){
            System.out.println("o valor de I :" + i);

        }



    }
}
