public class Vector {
    public static void main(String[]args){

        String s = "batata limao maca";

        String[] vect = s.split(" ");

        String word1 = vect[2];
        String word2 = vect[1];
        System.out.println(word1);
        System.out.println(word2);



    }
}
