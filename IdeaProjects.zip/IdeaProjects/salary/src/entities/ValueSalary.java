package entities;

public class ValueSalary {

    public static String name;
    public static double GrossSalary;
    public static double tax;

    // Calcula salario Liquido
    public static double SalaryWithTaxaDeducted(){
        return GrossSalary - tax;
    }
    //Aumento de salario de acordo com a porcentagem Declarada pelo operador
    public static double SalaryIncrease(double porcentagem){
        return SalaryWithTaxaDeducted() * (1.0 + porcentagem / 100 );
    }
    //Retorna Print na Class Program
    public static String toString(double newSalary){
        return name
                + " , "
                + String.format("%.2f ", GrossSalary)
                + String.format("O desconto foi de %.2f", tax)
                + String.format(" O seu novo salario com aumento é de: %.2f",newSalary);


    }


}
