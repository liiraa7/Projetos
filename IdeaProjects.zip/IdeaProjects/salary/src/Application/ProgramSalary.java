package Application;

import java.util.Scanner;
import java.util.Locale;

import entities.ValueSalary;

public class ProgramSalary {

    public static void main(String[]args){

        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);



            System.out.println("Enter your name ");
        ValueSalary.name = sc.nextLine();
            System.out.println("Enter your salary");
        ValueSalary.GrossSalary = sc.nextDouble();
            System.out.println("What is the discount amount");
        ValueSalary.tax = sc.nextDouble();

            System.out.println(ValueSalary.SalaryWithTaxaDeducted());

            System.out.println("Digite a porcentagem do aumento: ");

        int porcentagem  = sc.nextInt();
            System.out.println();
        ValueSalary.SalaryIncrease(porcentagem);

        double newSalary = ValueSalary.SalaryIncrease(porcentagem);
            System.out.println();
            System.out.println("New Salary with increase : " + ValueSalary.toString(newSalary));












    }
}
