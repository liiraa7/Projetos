package intities;

public class AccountInf {

    private int Account;
    private String name;

    public AccountInf(int account, String name) {
        this.Account = account;
        this.name = name;
    }

    public int getAccount() {
        return Account;
    }

    public void setAccount(int account) {
        Account = account;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
