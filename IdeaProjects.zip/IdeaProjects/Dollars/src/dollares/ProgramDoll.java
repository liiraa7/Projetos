package dollares;

import entities.Controll;

import java.util.Locale;
import java.util.Scanner;

public class ProgramDoll {
     public static void main(String[]args){

        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter how many dollars you want to buy : ");

        double dollars = sc.nextDouble();

        double newValue = Controll.ConvertDollar(Controll.DescontIOF(dollars));
        System.out.println();
        System.out.println("The amount you will pay in taxes is :  " + Controll.toString(newValue));





    }
}
