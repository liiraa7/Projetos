package entities;

public class Controll {


    public static final double VALUE_DOLLAR = 5.01;

    public static final double DESCONT_IOF = 0.06;

    // Converte dolares em moeda real
    public static double ConvertDollar(double dollar){
        return dollar * VALUE_DOLLAR;
    }

    public static double DescontIOF(double dollarAmount){
        return dollarAmount * (1 - DESCONT_IOF);

    }

    public static String toString(double Value){
        return ",  "
        + String.format("The Value in Real With discount: %.2f", Value);
    }

}
