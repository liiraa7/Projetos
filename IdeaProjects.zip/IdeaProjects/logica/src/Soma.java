import java.util.Scanner;

public class Soma {
    public static void main(String[]args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Por quantos minutos vc usou?");

        int min = sc.nextInt();
        int valorPago = 50;



        if (min > 100){
            valorPago = valorPago + 2 * (min - 100);
        }
        System.out.println(valorPago);

    }
}
