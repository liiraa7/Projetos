package application;

import entities.Product;

import java.util.Locale;
import java.util.Scanner;

public class Program {
    public static void main(String[] args) {

        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);


            System.out.println("Enter product Data: ");
            System.out.println("Name: ");
        String name = sc.nextLine();

            System.out.println("Price");
        double price = sc.nextDouble();

        System.out.println("Quantity: ");
        int quantity = sc.nextInt();

            Product product = new Product(name, price, quantity);


            System.out.println();

            System.out.println("Product Data: " + product);

        product.setName("Computer");
        product.setPrice(1200);


            System.out.println();

            System.out.println("Enter the number of products to be added in Stock");
        quantity = sc.nextInt();


        product.addProducts(quantity);

            System.out.println();
            System.out.println("Update Data product and price: " + product.getName() + " , "+ product.getPrice() + ", " + product.getQuantity());

            System.out.println();
            System.out.println("Enter the number of products remove in Stock");

            quantity = sc.nextInt();
        product.removeStock(quantity);

            System.out.print("Update Data: " + product);

            System.out.println();
            System.out.println("Enter the number of products remove in Stock");

        quantity = sc.nextInt();
        product.stockNew(quantity);
            System.out.println("Update: " + product);








        sc.close();
    }

}
