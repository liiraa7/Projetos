package entities;

public class Product {

    //Criação das variaveis Name/Price/Quantity
    String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public double totalValueInStock() {
        return price * quantity;

    }

    public void addProducts(int quantity) {
        this.quantity += quantity;

    }

    public void removeStock(int quantity) {
        this.quantity -= quantity;
    }

    public void stockNew(int quantity) {
        this.quantity -= quantity;
        if (this.quantity < 20) {
            System.out.println("Stock Low");
        }
    }

    public String toString() {
        return name
                + ", $ "
                + String.format("%.2f", price)
                + " , "
                + this.quantity
                + " Units, total "
                + String.format("%.2f", totalValueInStock());

    }
}
